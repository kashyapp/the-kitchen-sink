// Implementation and testing of a Set
// A Set is defined to be a Bag without duplicates, a bag
// where all the elements happen to have the occurrence count of 1.
// It is quite natural therefore that the CSet is implemented as
// a subclass of a CBag.

#include "CBag.h"
#include <assert.h>
using std::cout;
using std::endl;

class CSet : public CBag {
 public:
  bool memberof(const int elem) const { return count(elem) > 0; }

  // Overriding of CBag::put!
  void put(const int elem)
  { if(!memberof(elem)) CBag::put(elem); }

  CSet * clone(void) const
  { CSet * new_set = new CSet(); *new_set += *this; return new_set; }
  CSet(void) {}
};


int main(void)
{
  cout << "\nRegression testing of a CSet\n";
  CSet a;
  CSet b;
  assert( a.size() == 0 );
  assert( a.count(1) == 0 );
  assert( a == b );
  a.put(1);
  assert( a.size() == 1 );
  a.put(1);
  a.put(2);
  assert( a.size() == 2 );
  assert( a.count(1) == 1 );
  assert( a.count(2) == 1 );
  assert( a.count(0) == 0 );
  assert( a.memberof(1) && a.memberof(2) && !a.memberof(0) );
  assert( b <= a );
  assert( !(a <= b) );

  CSet & c = *(a.clone());
  assert( a == c );
  assert( a.del(1) );
  assert( !a.del(0) );
  assert( a <= c );
  assert( !(a == c) );
  a.put(3);
  assert( !(a <= c) );
  assert( !(a >= c) );
  a.del(3);
  a.put(1);
  assert( (a == c) );
  CSet d;
  assert( !(d == a) );
  d += a;
  assert( (d == a) );
  d += a;
  assert( (d == a) );

  {
    CBag ab; ab.put(1); ab.put(4);
    ab += a;
    assert( ab.del(4) && ab.del(1) );
    assert( ab == a );
  }
  {
    CBag ab; ab.put(1); ab.put(4);
    CSet as; as += a;
    as += ab;
    assert( as.del(4) );
    assert( as == a );
  }

  cout << "set a: " << a << endl;
  b.put(1);
  b.put(3);
  cout << "set b: " << b << endl;
  cout << "set c: " << c << endl;
  cout << "the result of foo(a,a,c) is: " << foo(a,a,c) << endl;
  cout << "the result of foo(a,b,c) is: " << foo(a,b,c) << endl;
  assert( !foo(a,b,c) );
  c.put(3);
  c.put(1);
  cout << "set c now: " << c << endl;
  cout << "the result of foo(a,b,c) is: " << foo(a,b,c) << endl;
  cout << "All tests passed" << endl;
  return 0;
}
