// Validation testing of a CBag

#include "CBag.h"
#include <assert.h>
using std::cout;
using std::endl;

int main(void)
{
  cout << "\nRegression testing of a CBag\n";
  CBag a;
  CBag b;
  assert( a.size() == 0 );
  assert( a.count(1) == 0 );
  assert( a == b );
  a.put(1);
  assert( a.size() == 1 );
  a.put(1);
  a.put(2);
  assert( a.size() == 3 );
  assert( a.count(1) == 2 );
  assert( a.count(2) == 1 );
  assert( a.count(0) == 0 );
  assert( b <= a );
  assert( !(a <= b) );
  CBag & c = *(a.clone());
  assert( a == c );
  assert( a.del(1) );
  assert( !a.del(0) );
  assert( a <= c );
  assert( !(a == c) );
  a.put(3);
  assert( !(a <= c) );
  assert( !(a >= c) );
  a.del(3);
  a.put(1);
  assert( (a == c) );
  CBag d;
  assert( !(d == a) );
  d += a;
  assert( (d == a) );
  d += a;
  assert( !(d == a) );
  assert( d.count(1) == 2*a.count(1) );

  cout << "bag a: " << a << endl;
  b.put(1);
  b.put(3);
  cout << "bag b: " << b << endl;
  cout << "bag c: " << c << endl;
  cout << "the result of foo(a,a,c) is: " << foo(a,a,c) << endl;
  assert( !foo(a,a,c) );
  cout << "the result of foo(a,b,c) is: " << foo(a,b,c) << endl;
  assert( !foo(a,b,c) );
  c.put(3);
  c.put(1);
  cout << "bag c now: " << c << endl;
  cout << "the result of foo(a,b,c) is: " << foo(a,b,c) << endl;
  assert( foo(a,b,c) );
  cout << "All tests passed" << endl;
  return 0;
}

