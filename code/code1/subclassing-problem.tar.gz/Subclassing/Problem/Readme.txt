Please consult
   http://pobox.com/~oleg/ftp/Computation/Subtyping/Trouble.html

See a Makefile as to building and running the examples
