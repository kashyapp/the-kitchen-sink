// Implementation #2 of a function foo()
// $Id$

#include "CBag.h"

// A sample function. Given three bags a, b, and c, it decides
// if a+b is a subbag of c
// Amost identical to foo1 implementation; only memory for
// a_clone is allocated on stack rather than on heap
bool foo(const CBag& a, const CBag& b, const CBag& c)
{
  CBag ab;
  ab += a;			// Clone a to avoid clobbering it
  ab += b;			// ab is now the union of a and b
  bool result = ab <= c;
  return result;
}

