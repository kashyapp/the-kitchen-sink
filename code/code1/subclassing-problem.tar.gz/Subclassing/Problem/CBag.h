// 			A Bag of integers
//			    Interface
// It is deliberately made simple and straightforward. Yet it is functional
// and sufficient for the example at hand.
// $Id: CBag.h,v 1.2 2003/01/27 21:11:50 oleg Exp oleg $

#include <iostream>
using std::ostream;

typedef int const * CollIterator;

class CBag {
 public:
  int size(void) const;			// The number of elements in the bag
  virtual void put(const int elem);	// Put an element into the bag
  int count(const int elem) const;	// Count the number of occurrences
				        // of a particular element in the bag
  virtual bool del(const int elem);     // Remove an element from the bag
					// Return false if the element
					// didn't exist
  CollIterator begin(void) const;	// Standard enumerator interface
  CollIterator end(void) const;

  CBag(void);
  virtual CBag * clone(void) const;	// Make a copy of the bag
 private:
  enum { maxsize = 25 };		// A primitive implementation, but
  int elems[maxsize];			// will do
  int curr_size;
};

// Standard "print-on" operator
ostream& operator << (ostream& os, const CBag& bag);

// Union (merge) of the two bags
// The return type is void to avoid complications with subclassing
// (which incidental to the current example)
void operator += (CBag& to, const CBag& from);

// Determine if CBag a is subbag of CBag b
bool operator <= (const CBag& a, const CBag& b);

inline bool operator >= (const CBag& a, const CBag& b)
{ return b <= a; }

// Structural equivalence of the bags
// Two bags are equal if they contain the same number of the same elements
inline bool operator == (const CBag& a, const CBag& b)
{ return a <= b && a >= b; }

// A sample function. Given three bags a, b, and c, it decides
// if a+b is a subbag of c
bool foo(const CBag& a, const CBag& b, const CBag& c);
