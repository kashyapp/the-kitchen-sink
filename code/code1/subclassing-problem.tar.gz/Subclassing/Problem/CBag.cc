// 		Implementation of the Bag of integers
// $Id: CBag.cc,v 1.1 2000/07/31 19:38:21 oleg Exp $

#include "CBag.h"
#include <assert.h>

// Methods of the CBag itself
// These functions are privy to the details of the CBag implementation

CBag::CBag(void) : curr_size(0) {}

// The number of elements in the bag
int CBag::size(void) const { return curr_size; }

// Put an element into the bag
void CBag::put(const int elem)
{
  assert( curr_size < maxsize );
  elems[curr_size++] = elem;
}

// Remove an element from the bag
// Return false if the element didn't exist
bool CBag::del(const int elem)
{
  int * p = elems;
  int * const pend = elems + curr_size;
  for(; p < pend; p++)
    if(	*p == elem )
      break;
  if( p == pend )		// 'elem' did not exist in the CBag
    return false;
  for(; p < pend -1; p++)
    *p = *(p+1);
  curr_size--;
  return true;
}

// Count the number of occurrences of a particular element in the bag
int CBag::count(const int elem) const
{
  int count = 0;
  for(const int * p = elems; p < elems + curr_size; p++)
    if( *p == elem )
      count++;
  return count;
}

// Standard enumerator interface
CollIterator CBag::begin(void) const { return elems; }
CollIterator CBag::end(void) const   { return elems + curr_size; }

// Make a copy of the bag
CBag * CBag::clone(void) const
{
  CBag * new_bag = new CBag();
  *new_bag += *this;
  return new_bag;
}


// Implementation of CBag "methods" (operations, actually)
// All of the following functions rely on the public CBag interface _only_

// Standard "print-on" operator
ostream& operator << (ostream& os, const CBag& bag)
{
  if( bag.size() == 0 )
    return os << "{}";
  CollIterator p = bag.begin();
  os << "{" << *p++;
  while(p != bag.end())
    os << ", " << *p++;
  return os << "}";
}


// Union (merge) of the two bags
void operator += (CBag& to, const CBag& from)
{
  for(CollIterator p = from.begin(); p != from.end(); p++)
    to.put(*p);
}

// Determine if CBag a is subbag of CBag b
// A very naive implementation
bool operator <= (const CBag& a, const CBag& b)
{
  for(CollIterator p = a.begin(); p != a.end(); p++)
    if( a.count(*p) > b.count(*p) )
      return false;
  return true;
}

