// Implementation #1 of a function foo()
// $Id$

#include "CBag.h"

// A sample function. Given three bags a, b, and c, it decides
// if a+b is a subbag of c
bool foo(const CBag& a, const CBag& b, const CBag& c)
{
  CBag & ab = *(a.clone());	// Clone a to avoid clobbering it
  ab += b;			// ab is now the union of a and b
  bool result = ab <= c;
  delete &ab;
  return result;
}

