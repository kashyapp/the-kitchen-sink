//     	      A Bag of integers, in an anti-OOP style
//			    Interface
// BRules are in effect, see Readme.txt in this directory
//
// The interface is deliberately made simple and straightforward. Yet
// it is functional and sufficient for the example at hand.
//
// $Id: FBag.h,v 1.2 2003/01/27 21:24:38 oleg Exp oleg $

#include <iostream>
using std::ostream;

class FBag {
 public:
  FBag(void);
  FBag(const FBag& another);		// Copy-constructor
  ~FBag(void);

 private:
  class Cell;
  const Cell * const head;
  FBag(const Cell * const cell);

  friend FBag put(const FBag& bag, const int elem);
  friend FBag del(const FBag& bag, const int elem);
  template<typename Functor, typename Seed> friend
    Seed fold(const FBag& bag, const Functor& functor, const Seed seed);

  FBag& operator = (const FBag&);	// Unimplemented and forbidden
};

int size(const FBag& bag);		// The number of elements in the bag
int count(const FBag&, const int elem);	// Count the number of occurrences

// Put an element into the bag
FBag put(const FBag& bag, const int elem);

// Remove an element from the bag. No error if the element didn't exist
FBag del(const FBag& bag, const int elem);     


// If a bag is empty, return the seed
// Otherwise, return
// functor(bag.e1,functor(bag.e2, ... functor(bag.en,seed)))
template<typename Functor, typename Seed>
Seed fold(const FBag& bag, const Functor& functor, const Seed seed);

// Standard "print-on" operator
ostream& operator << (ostream& os, const FBag& bag);

// Union (merge) of the two bags
FBag operator + (const FBag& bag1, const FBag& bag2);

// Determine if FBag a is subbag of FBag b
bool operator <= (const FBag& a, const FBag& b);

inline bool operator >= (const FBag& a, const FBag& b)
{ return b <= a; }

// Structural equivalence of the bags
// Two bags are equal if they contain the same number of the same elements
inline bool operator == (const FBag& a, const FBag& b)
{ return a <= b && a >= b; }

// Given a bag, return a similar bag without duplicates
FBag remove_duplicates(const FBag& bag);

// Verify bag's invariants
void verify(const FBag& bag);

// A sample function. Given three bags a, b, and c, it decides
// if a+b is a subbag of c
bool foo(const FBag& a, const FBag& b, const FBag& c);

