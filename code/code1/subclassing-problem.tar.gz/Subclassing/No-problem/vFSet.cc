// Implementation and testing of a FSet
//
// A Set is defined to be a Bag without duplicates, a bag
// where all the elements happen to have the occurrence count of 1.
// A set of all Sets therefore is a subset of a set of all Bags.
// A FSet therefore is a subtype of a FBag. See Readme.txt in this
// directory for an extensive discussion.

#include "FBag.h"
#include <assert.h>
using std::cerr;
using std::cout;
using std::endl;

class FSet : public FBag {
 public:
  FSet(void) {}
  FSet(const FBag& bag) : FBag(remove_duplicates(bag)) {}
};

bool memberof(const FSet& set, const int elem)
{ return count(set,elem) > 0; }

// Verify set's invariants
void verify(const FSet& set)
{
  cerr << "Verifying FSet's invariants given " << set << " ...";
  const FSet set1 = put(set,5);
  assert( size(set1) == 1 + size(set) - count(set,5) &&
	  count(set1,5) == 1 );
  const FSet set2 = put(set1,5);
  assert( size(set2) == size(set1) && count(set2,5) == 1 );
  assert( set1 == set2 );
  assert( count(del(set2,5),5) == 0 );
  cerr << "Done" << endl;
}

int main(void)
{
  cout << "\nRegression testing of a FSet\n";
  const FSet a;
  const FSet b;
  assert( size(a) == 0 );
  assert( count(a,1) == 0 );
  assert( a == b );

  const FSet a1 = put(a,1);
  assert( size(a1) == 1 );

  const FSet a112 = put(put(a1,2),1);
  assert( size(a112) == 2 );
  assert( count(a112,1) == 1 );
  assert( count(a112,2) == 1 );
  assert( count(a112,0) == 0 );
  assert( memberof(a112,1) && memberof(a112,2) && !memberof(a112,0) );
  assert( b <= a112 );
  assert( !(a112 <= b) );

  verify(a112);			// Verify a112 as a set and as a FBag
  verify(static_cast<const FBag&>(a112));

  const FSet c = a112; 	// cloning
  assert( a112 == c );
  {
    const FSet d;
    assert( !(d == a112) );
    const FSet donce = d + a112;
    assert( (donce == a112) );
    const FSet dtwice = donce + a112;
    assert( dtwice == a112 );
  }
  {
    const FSet a12 = del(a112,1);
    //assert( !a.del(0) );
    assert( a12 <= c );
    assert( !(a12 == c) );
    const FSet a123 = put(a12,3);
    assert( !(a123 <= c) );
    assert( !(a123 >= c) );
    assert( (put(del(a123,3),1) == c) );
  }

  {
    const FBag ab = put(put(FBag(),1),4) + a112;
    const FBag abm14 = del(del(ab,4),1);
    assert( abm14 == a112 );
  }
  {
    const FSet as = a112 + put(put(FBag(),1),4);
    assert( del(as,4) == a112 );
  }

  cout << "set a112: " << a112 << endl;
  const FSet b13 = put(put(b,1),3);
  cout << "set b13: " << b13 << endl;
  cout << "set c: " << c << endl;
  cout << "the result of foo(a112,a112,c) is: " << foo(a112,a112,c) << endl;
  cout << "the result of foo(a112,b13,c) is: " << foo(a112,b13,c) << endl;
  assert( !foo(a112,b13,c) );
  const FSet cnew = put(put(c,3),1);
  cout << "set c now: " << cnew << endl;
  cout << "the result of foo(a112,b13,cnew) is: " << foo(a112,b13,cnew)
       << endl;
  cout << "\nAll tests passed" << endl;
  return 0;
}
