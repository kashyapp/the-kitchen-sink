// Validation testing of a FBag

#include "FBag.h"
#include <assert.h>
using std::cout;
using std::endl;

int main(void)
{
  cout << "\nRegression testing of a FBag\n";
  const FBag a;
  const FBag b;
  assert( size(a) == 0 );
  assert( count(a,1) == 0 );
  assert( a == b );

  const FBag a1 = put(a,1);
  assert( size(a1) == 1 );

  const FBag a112 = put(put(a1,2),1);
  assert( size(a112) == 3 );
  assert( count(a112,1) == 2 );
  assert( count(a112,2) == 1 );
  assert( count(a112,0) == 0 );
  assert( b <= a112 );
  assert( !(a112 <= b) );

  verify(a112);

  const FBag c = a112; 	// cloning
  assert( a112 == c );
  {
    const FBag d;
    assert( !(d == a112) );
    const FBag donce = d + a112;
    assert( (donce == a112) );
    const FBag dtwice = donce + a112;
    assert( !(dtwice == a112) );
    assert( count(dtwice,1) == 2*count(a112,1) );
  }
  {
    const FBag a12 = del(a112,1);
    //assert( !a.del(0) );
    assert( a12 <= c );
    assert( !(a12 == c) );
    const FBag a123 = put(a12,3);
    assert( !(a123 <= c) );
    assert( !(a123 >= c) );
    assert( (put(del(a123,3),1) == c) );
  }

  cout << "bag a112: " << a112 << endl;
  const FBag b13 = put(put(b,1),3);
  cout << "bag b13: " << b13 << endl;
  cout << "bag c: " << c << endl;
  cout << "the result of foo(a112,a112,c) is: " << foo(a112,a112,c) << endl;
  assert( !foo(a112,a112,c) );
  cout << "the result of foo(a112,b13,c) is: " << foo(a112,b13,c) << endl;
  assert( !foo(a112,b13,c) );
  const FBag cnew = put(put(c,3),1);
  cout << "bag c now: " << cnew << endl;
  cout << "the result of foo(a112,b13,cnew) is: " << foo(a112,b13,cnew)
       << endl;
  assert( foo(a112,b13,cnew) );
  cout << "\nAll tests passed" << endl;
  return 0;
}

