Please consult
   http://pobox.com/~oleg/ftp/Computation/Subtyping/Preventing-Trouble.html

See a Makefile as to building and running the examples
