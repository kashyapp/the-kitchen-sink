// 		Implementation of the Bag of integers
// $Id: FBag.cc,v 1.2 2003/01/27 21:25:45 oleg Exp oleg $

#include "FBag.h"
#include <assert.h>
using std::cerr;
using std::endl;

// A list of cells -- FBag's actual implementation
// Each cell holds one element of a bag.

struct FBag::Cell {
  const int elem;
  const Cell * const next;
  Cell(const int _elem, const Cell * const _next) :
    elem(_elem), next(_next) {}

  class CellStorage;
  static CellStorage storage;

  void * operator new(size_t);
  void * operator new(size_t, void * ptr) { return ptr; }
};

// CellStorage -- a storage of cells
//
// All instances of FBag::Cell are allocated from the CellStorage, and
// are subject to garbage collection.  CellStorage implements a simple
// mark-and-sweep collector. The collector is entered when you call a
// function gc(const int reserve) below and the function finds that
// there are fewer than 'reserve' free cells left in the
// CellStorage. The collector scans and marks all the cells reachable
// from the roots, and frees the unmarked cells.
//
// By invariant, the roots of all live chains are the heads of
// currently active FBags. FBag's constructors register the cell chains
// they possess as active roots. FBag's destructor unregisters its
// chain.  The only chance the invariant above could be broken if you
// allocate a cell and call gc() before you put the new cell into a
// list that belongs to a FBag. Note, gc() is a private function, and
// not generally accessible. It is being called only by put() and
// del() functions below, which make sure the invariant holds (they
// call gc() right at the very beginning).
//
// Again, CellStorage is a very private class. It is not available (in
// fact, unknown) outside of this file. CellStorage is a private
// allocator/garbage collector of cells, and by necessity uses
// mutation. It is a singleton class, so referential transparency is
// not important. No other class or function in this project use
// mutation; the rest of this project is referentially transparent.

class FBag::Cell::CellStorage
{
  enum {capacity = 12};		// How much storage to reserve
  enum {low_water_mark = capacity/4}; // Start collection if
				// the number of free cells drops
				// below the low-water_mark
  int free_cells;		// The number of free cells

  struct CellStored : public Cell {
    enum {Marked, Swept, Free} flag;
    CellStored(void) : Cell(0,0), flag(Free) {}
  };
  CellStored storage[capacity];	// The storage itself

  enum { roots_max = 20 };	// Keeping track of live roots
  const Cell * roots[roots_max];
  int roots_curr;

				// Find the storage location of a cell
  CellStored * downcast(const Cell * const cell) {
    const CellStored * p = static_cast<const CellStored *>(cell);
    if( p==0 ) return 0;
    assert( p >= storage && p < storage + capacity );
    return const_cast<CellStored*>(p);
  }

public:
  CellStorage(void) : free_cells(capacity), roots_curr(0) {}

				// Allocate a cell
  Cell * new_cell(void)
  {
    assert( free_cells > 0 );
    for(CellStored * p = storage; p < storage + capacity; p++)
      if( p->flag == CellStored::Free )
       {
	 p->flag = CellStored::Swept;
	 free_cells--;
	 return p;
       }
    assert(0);			// Can't happen
    return 0;
  }

				// Register an alive chain of cells
				// (which is rooted in a head of a bag)
  void reg_chain(const Cell * const cell)
  {
    if( cell == 0 ) return;
    // cerr << "Registering root: " << hex << long(cell) << endl;
    assert( roots_curr < roots_max );
    roots[roots_curr++] = cell;
  }

				// Unregister an alive chain
  void dereg_chain(const Cell * const cell)
  {
    // cerr << "Deregistering root: " << hex << long(cell) << endl;
    register int i = roots_curr;
    while( --i >= 0 )
      if( roots[i] == cell )
	break;
    assert( i >= 0 );
    for(register int j = i; j+1<roots_curr; j++)
      roots[j] = roots[j+1];
    roots_curr--;
  }
				// Initiate garbage collection
  void gc(const int reserve = low_water_mark)
  {
    if( free_cells > reserve )
      return;				// There are enough free cells

    cerr << "Staring gc; live roots: " << roots_curr
	 << "  free cells " << free_cells << endl;

    for(int i=0; i<roots_curr; i++)	// mark alive cells
      for(CellStored * chain = downcast(roots[i]); chain != 0;
	  chain = downcast(chain->next))
	if( chain->flag == CellStored::Marked )
	  break;			// a chain has been marked already
        else
	{
	  assert( chain->flag == CellStored::Swept );
	  chain->flag = CellStored::Marked;
	}
				// sweep the storage
    for(CellStored * p = storage; p < storage + capacity; p++)
      if( p->flag == CellStored::Marked )
	p->flag = CellStored::Swept;
      else if( p->flag == CellStored::Swept )
	p->flag = CellStored::Free, free_cells++;
    cerr << "Ending gc; free cells " << free_cells << endl;
  }
  
};

FBag::Cell::CellStorage FBag::Cell::storage;
void * FBag::Cell::operator new(size_t) { return storage.new_cell(); }

// Methods of the FBag itself
// These functions are privy to the details of the FBag implementation

FBag::FBag(void) : head(0) {}

// A private constructor; mark the chain of cells as alive
FBag::FBag(const FBag::Cell * const cell) : head(cell)
{ Cell::storage.reg_chain(head); }

// Copy-constructor
FBag::FBag(const FBag& another) : head(another.head)
{
  Cell::storage.reg_chain(head);
}

// Destructor
FBag::~FBag(void) { if(head) Cell::storage.dereg_chain(head); }


// Put an element into the bag
FBag put(const FBag& bag, const int elem)
{
  FBag::Cell::storage.gc(1);
  return FBag(new FBag::Cell(elem,bag.head));
}


// Remove an element from the bag
FBag del(const FBag& bag, const int elem)
{
  FBag::Cell::storage.gc(10);	// This practically forces the gc
  struct f {
    const FBag::Cell * const operator ()
      (const FBag::Cell * const cells, const int elem) const {
      if( cells == 0 ) return cells;
      else if( cells->elem == elem )
	return cells->next;
      else {
	const FBag::Cell * const new_chain = 
	  new FBag::Cell(cells->elem,(*this)(cells->next,elem));
	return new_chain;
      }
    }
  };
  return FBag(f()(bag.head,elem));
}

// If a bag is empty, return seed
// Otherwise, return
// functor(bag.e1,functor(bag.e2, ... functor(bag.en,seed)))
template<typename Functor, typename Seed>
Seed fold(const FBag& bag, const Functor& functor, const Seed seed)
{
  struct f {
    const Functor& functor;
    Seed operator () (const FBag::Cell * const cells, const Seed seed) const
    {
      return  cells == 0 ? seed :
	functor(cells->elem,(*this)(cells->next,seed));
    }
    f(const Functor& _functor) : functor(_functor) {}
  };
  return f(functor)(bag.head,seed);
}

// Implementation of FBag "methods" (operations, actually)
// All of the following functions rely on the public FBag interface _only_

// The number of elements in the bag
struct size_f {
  int operator()(const int, const int count) const { return 1+count; }
};
int size(const FBag& bag)
{
  return fold(bag,size_f(),0);
}

// Count the number of occurrences of a particular element in the bag
		// I wish gcc allowed template instantiation with local
		// classes
struct count_f {
  const int elem;
  int operator()(const int curr, const int count) const
  { return curr == elem ? 1+count : count; }
  count_f(const int _elem) : elem(_elem) {}
};

int count(const FBag& bag, const int elem)
{
  return fold(bag,count_f(elem),0);
}

// Standard "print-on" operator
struct print_f {
  ostream& os;
  const bool is_first;
  print_f(ostream& _os, const bool _is_first)
    : os(_os), is_first(_is_first) {}
  print_f operator() (const int elem, const print_f seed) const
  { return print_f(seed.os << (seed.is_first ? "{" : ", ") << elem, false); }
};
ostream& operator << (ostream& os, const FBag& bag)
{
  print_f seed(os,true);
  print_f result = fold(bag,seed,seed);
  return result.os << (result.is_first ? "{}" : "}");
}


// Union (merge) of the two bags
struct union_f {
  FBag operator() (const int elem, const FBag seed) const {
    return put(seed,elem);
  }
};

FBag operator + (const FBag& bag1, const FBag& bag2)
{
  return fold(bag1,union_f(),bag2);
}

// Determine if FBag a is subbag of FBag b
// A very naive implementation
struct subbag_f {
  const FBag& a;
  const FBag& b;
  subbag_f(const FBag& _a, const FBag& _b) : a(_a), b(_b) {}
  bool operator() (const int elem, const bool seed) const
  { return seed && count(a,elem) <= count(b,elem); }
};

bool operator <= (const FBag& a, const FBag& b)
{
  return fold(a,subbag_f(a,b),true);
}


// Given a bag, return the same bag without duplicates
struct remdupl_f {
  FBag operator() (const int elem, const FBag seed) const
  { return count(seed,elem) > 0 ? seed : put(seed,elem); }
};

FBag remove_duplicates(const FBag& bag)
{
  return fold(bag,remdupl_f(),FBag());
}

// A sample function. Given three bags a, b, and c, it decides
// if a+b is a subbag of c
bool foo(const FBag& a, const FBag& b, const FBag& c)
{
  return (a+b) <= c;
}

// Verify bag's invariants
void verify(const FBag& bag)
{
  cerr << "Verifying FBag's invariants given " << bag << " ...";
  const FBag bag1 = put(bag,5);
  assert( size(bag1) == 1 + size(bag) &&
	  count(bag1,5) == 1 + count(bag,5) );
  const FBag bag2 = put(bag1,5);
  assert( size(bag2) == 2 + size(bag) &&
	  count(bag2,5) == 2 + count(bag,5) );
  assert( count(del(bag2,5),5) == 1 + count(bag,5) );
  cerr << "Done" << endl;
}
